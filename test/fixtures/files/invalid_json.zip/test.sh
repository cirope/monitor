#!/usr/bin/env sh

set -eu

ls
